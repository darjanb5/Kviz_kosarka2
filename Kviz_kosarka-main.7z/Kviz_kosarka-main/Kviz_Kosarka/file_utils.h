#ifndef FILE_UTILS_H
#define FILE_UTILS_H

void kopirajDatoteku(const char* izvornaDatoteka, const char* odredisnaDatoteka);
void obrisiDatoteku(const char* nazivDatoteke);

#endif 